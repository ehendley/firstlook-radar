# 初见雷达

上传一张照片，获得属于这张照片的初见类型、六维视觉雷达、具体亮点和场景建议，生成可分享的 PNG 卡片。

前端部署到 **GitHub Pages**，模型密钥保存在 **Cloudflare Workers Secret**。首选 **阿里云百炼 `qwen3-vl-plus`，华北2（北京）**。所有模型文字以纯文本显示，照片和报告仅在浏览器与请求内存中使用，项目不建立照片数据库。

## 本地体验

需要 Node.js 22 或以上，前端没有第三方运行依赖。

```sh
npm run dev
```

打开终端显示的本机地址。点击“先看示例”可体验完整报告和分享卡；示例明确标注，未连接后端时不会冒充真实分析。上传照片可以先预览，真实分析需要完成下面的配置。

```sh
npm test
npm run check
npm run build
```

`dist/` 只包含 `public/` 的静态资源，不包含 Worker、测试、环境变量或密钥。发布使用相对资源地址，支持 `https://用户名.github.io/firstlook-radar/` 子路径。

## 需要的账号

1. GitHub：托管代码和 Pages 网页。若使用免费账号，项目仓库需要公开，仓库里不放 Key。
2. 阿里云百炼：注册、实名认证并开通模型服务，选择北京地域，创建 API Key，复制同一业务空间的 API Host。可只授权视觉模型。开通、实名认证、协议和充值由账号持有人完成。
3. Cloudflare：托管一个 Worker API，保管百炼 Key。无需购买域名；会生成 `workers.dev` 地址。

不要把密码、验证码或长期有效的 API Key 提交到 GitHub、写入 `public/config.json` 或粘贴到聊天。Key 在 Cloudflare 的 Secret 输入框或 Wrangler 的交互输入中配置。

## 发布后端

在 `worker/wrangler.jsonc` 中填写公开配置：

```json
"vars": {
  "ALLOWED_ORIGINS": "https://你的用户名.github.io",
  "QWEN_BASE_URL": "https://你的业务空间ID.cn-beijing.maas.aliyuncs.com/compatible-mode/v1",
  "QWEN_MODEL": "qwen3-vl-plus"
}
```

`ALLOWED_ORIGINS` 只写来源，不包含 `/firstlook-radar/` 路径，不加末尾斜杠。多个来源用逗号分隔。开发时可加 `http://127.0.0.1:4173`，上线时保留需要的来源即可。Base URL 以百炼控制台显示的同地域 API Host 为准。

使用官方 Wrangler（首次会从 npm 获取该工具，需要联网）：

```sh
npx wrangler login
npm run worker:deploy
npx wrangler secret put DASHSCOPE_API_KEY --config worker/wrangler.jsonc
```

最后一个命令会交互式接收密钥，不把 Key 写在命令参数里。也可以在 Cloudflare 的 Worker → Settings → Variables and Secrets 中新增同名 **Secret**。密钥没有设置时，接口保持关闭。

配置中的原生 `ANALYZE_RATE_LIMITER` 绑定为每个 IP 每 60 秒约 3 次请求，Wrangler 需支持 Rate Limiting binding（4.36.0 或以上）。如同账号已有相同 namespace，改为账号内独立的整数 ID。Cloudflare 官方说明该限制是各节点近似限制，**不是全局费用上限**；CORS 也不是用户身份验证。公开推广前，应按实际流量增加人机验证/账号额度，并在百炼控制台设置可用的预算与告警。

健康检查：访问 `https://你的Worker地址/api/health`。它只返回 `configured` 布尔值；配置、Key 或限流绑定缺失时不会调用模型。`configured: true` 只证明配置齐全，首次真实照片请求成功后才算模型连通验证完成。

本地后端可用 `npm run worker:dev`；将密钥保存在被 gitignore 排除的 `worker/.dev.vars` 中，勿放前端目录。实际照片会从浏览器经 Worker 发送至百炼；供应商的处理规则以其政策为准。

## 发布网页

把 `public/config.json` 改为：

```json
{ "apiBaseUrl": "https://你的Worker地址" }
```

不要填写 `/api/analyze`，前端会追加接口路径。这里是公开地址，不是密钥。

创建 `firstlook-radar` 仓库，上传本项目代码，默认分支使用 `main`。在 GitHub 仓库 **Settings → Pages → Build and deployment → Source** 中选择 **GitHub Actions**。项目自带 `.github/workflows/pages.yml`，推送到 main 后会运行检查并发布。没有 Key 时也能先发布示例体验，但真实分析会清楚显示尚未开通。

## 结果设计与接口

完整产品设计在 [docs/result-design.md](docs/result-design.md)。六维分别为亲近感、清爽感、松弛感、利落感、存在感、故事感；数字表示本张照片的视觉呈现强度，不是颜值、人格或陌生人调查分数。不能判断的维度保留 `null`，前端显示“依据不足”。

`POST /api/analyze`：

```json
{ "image": "data:image/jpeg;base64,...", "scene": "daily", "consent": true }
```

scene 为 `daily`、`avatar` 或 `work`。图片支持 JPEG、PNG、WebP；前端原图最大 10MB、长边缩至 1280 后重编码，后端解码后最大 3MiB，并校验魔数。单人照可分析，无人物、多人或严重模糊会请求换图。

成功返回 `{ "mode": "live", "report": { ... } }`；不可分析时 report 的 status 为 `retake`。错误返回 `{ "error": { "code": "...", "message": "中文提示" } }`。模型输出经本地验证后才能进入结果页，非法 JSON 不伪装成报告。

## 选型依据和验证范围

- [百炼视觉 API](https://help.aliyun.com/zh/model-studio/qwen-vl-compatible-with-openai)
- [结构化输出及 JSON Mode](https://help.aliyun.com/zh/model-studio/qwen-structured-output)：多模态输入不能据通用型号清单假设严格 JSON Schema 生效，首版采用 JSON Object + 本地验证。
- [获取 Key](https://help.aliyun.com/zh/model-studio/get-api-key)、[地域与 API Host](https://help.aliyun.com/zh/model-studio/regions)
- [GitHub Pages 静态托管](https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages)
- [Workers Secrets](https://developers.cloudflare.com/workers/configuration/secrets/)、[原生限流](https://developers.cloudflare.com/workers/runtime-apis/bindings/rate-limit/)

本地自动测试覆盖协议验证、上传边界、后端请求和错误处理；上游模型响应在测试中由受控响应代替，**不代表已进行真实模型效果测试**。账号/Key 就绪后还需进行真实连通验证。项目未引入收费、账户体系、公开相册或第三方追踪。
