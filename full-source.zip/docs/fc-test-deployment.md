# 阿里云 FC 手机连通性测试后端

这是待部署、可审阅的替代后端，尚未创建阿里云资源，也未修改线上 API 地址。目标是在中国大陆手机不开 VPN 的环境验证连接。保留 GitHub Pages 前端；由北京地域 FC 接收授权后的照片并直接调用现有北京百炼业务空间。

## 代码与边界

`fc/server.mjs` 将 Node HTTP 请求适配成标准 `Request`，调用现有 `worker/index.mjs` 的 `createHandler()`。报告提示词、照片验证、CORS、供应商地址限制、报告校验与安全错误响应均复用现有代码。没有新增 npm 依赖，也没有复制模型逻辑。

代码包根目录须保留下列相对路径；不能只上传 server.mjs：

```text
fc/server.mjs
worker/index.mjs
worker/prompt.mjs
public/lib/report.mjs
```

三条 API 路径保持不变：`GET /api/health`、`OPTIONS /api/analyze`、`POST /api/analyze`。模型请求仍为一次调用、45 秒超时、关闭思考模式；不会自动重发照片分析。Node 层按共享 `MAX_REQUEST_BYTES` 限制上传正文，既检查声明长度，也累计检查分块正文；客户端在传输或等待结果期间断开，会取消共享 handler 的上游请求。程序不记录照片、密钥、返回报告或上游错误正文。

当前未依赖任何 FC 客户端 IP 请求头。适配器忽略传入 `CF-Connecting-IP`，设置内部固定值 `0.0.0.0`，让所有访客共用一个实例内的限流桶：滚动 60 秒内最多接受 3 次有效分析。此限制是**实例内总频率限制**，不是每个用户 3 次。健康检查和预检不占用该分析桶。实例重启、冷启动和实例替换会重置内存桶，因此即使设置最大实例数 1，它也不是全站持久费用上限。当前方案只供小范围连通性测试；公开推广前需要持久化总额度控制。

## 控制台部署配置

只准备配置，不默认同意新产品协议、授权或产生费用。用户应在 FC 控制台查看当前账号适用条款、试用资格及计费状态，并自行确认必要授权。官方说明新阿里云用户的 FC 可自动开通，但实际使用即视为同意服务协议与 SLA；未实际使用不产生费用。[FC 自动开通说明](https://help.aliyun.com/zh/functioncompute/fc/product-overview/product-changes-automatic-activation-of-function-compute)

| 配置 | 选值 |
|---|---|
| 地域 | 华北 2（北京），`cn-beijing` |
| 函数类型 | Web 函数，自定义运行时 |
| 运行时 | `custom.debian12`，x86_64 |
| Node 官方公共层 | `Nodejs24`，v2 或经过兼容验证的更新修复版 |
| 本次已查证层 ARN | `acs:fc:cn-beijing:official:layers/Nodejs24/versions/2` |
| 层对应 Node 版本 | 24.22.1 |
| 启动命令 | `/opt/nodejs24/bin/node` |
| 启动参数 | `/code/fc/server.mjs` |
| 服务监听 | `0.0.0.0:9000`，控制台端口也设为 `9000` |
| 函数执行超时 | 90 秒 |
| 单实例并发 | 1 |
| 最大实例数 | 1 |
| 最小实例数 / 预置实例 | 0；先不创建预置实例 |
| 网络 | 允许访问公网；不需要新建 VPC、NAS、OSS 或数据库 |
| HTTP 触发器 | 测试用公网 HTTPS 地址，方法 GET、POST、OPTIONS |
| HTTP 平台认证 | 测试前端需匿名调用；请求来源校验与限流仍由共享代码执行 |
| 日志 | 不增加业务日志、请求正文或密钥日志；无需额外开启日志投递 |

官方层文档确认 Node 二进制目录为 `/opt/nodejs24/bin`，层挂载到 `/opt`，FC 代码位于 `/code`。使用上述二进制绝对路径，不依赖控制台的 PATH 自动配置。部署后核对实际 Node 版本，不要用已经停止上游安全维护的内置 `nodejs20` 替代。[官方 Nodejs24 层说明](https://github.com/awesome-fc/awesome-layers/blob/main/docs/Nodejs24/README.md)、[2026-10-24 安全公告](https://help.aliyun.com/zh/functioncompute/security-notice-function-compute-nodejs-runtime-vulnerability)、[自定义运行时配置](https://help.aliyun.com/zh/functioncompute/custom-runtime/)

建议选择低 CPU/内存规格，最终以控制台兼容规格为准。FC 按量计费，并非永久免费；当前标准第一阶梯为 0.00011 元/CU，费用还受配置、等待时长、请求和网络用量影响。活跃函数存在按小时最低费用规则，具体以账号账单及有效试用额度为准。不要自动购买资源包或假定必须充值固定金额。[FC 按量计费](https://help.aliyun.com/zh/functioncompute/pay-as-you-go-billing-methods)

## 由用户填入的后台配置

| 环境变量 | 值 |
|---|---|
| `ALLOWED_ORIGINS` | `https://ehendley.github.io` |
| `QWEN_BASE_URL` | `https://ws-bovitj0n7v3h96y9.cn-beijing.maas.aliyuncs.com/compatible-mode/v1` |
| `QWEN_MODEL` | `qwen3-vl-plus` |
| `DASHSCOPE_API_KEY` | 用户从百炼复制完整 Key，直接填入 FC 后台；不写入源码、ZIP、GitHub 或聊天 |

FC 环境变量会加密存储，但管理控制台可能回显明文。用户输入后不读取环境变量列表的值，不在日志中打印配置；如需控制台不可见的秘密托管，可另用 KMS，并评估额外权限及费用。[环境变量说明](https://help.aliyun.com/zh/functioncompute/environment-variables)

## 测试、切换和验收

1. 部署后先在手机相同网络打开 FC 的 `/api/health`，应得到 `{"configured":true}`。默认域名有时会以附件形式下载 JSON，这不是分析失败，后续仍需从网页 fetch 验证。
2. 用专门测试页面或本地配置指向该 FC URL，检查健康检测、CORS 预检、上传和真实报告。在大陆手机不开 VPN 的情况下确认成功，不能用本机测试代替该验收。
3. 通过后再把前端 `config.json` 的 `apiBaseUrl` 改为控制台实际生成的 FC HTTPS 地址并发布。保留原 Cloudflare 配置，便于回退；不把任何 API Key 放到前端。
4. 手机刷新正式网页，上传经本人授权的单人照片；确认完整报告和分享卡。到这一步才能宣布手机端问题解决。

FC 默认域名仅用于测试，**不作为长期公开网站地址承诺**。正式对外网站服务需要使用符合要求的自定义域名，中国内地地域域名需要备案。当前用户无自有域名，正式推广前仍需处理这一项。[HTTP 触发器限制与 CORS](https://help.aliyun.com/zh/functioncompute/http-triggers-overview)、[自定义域名说明](https://help.aliyun.com/zh/functioncompute/configure-custom-domain-names)

## 本地验证

```sh
node --test tests/fc.test.mjs
npm test
npm run check
```

FC 回归测试使用真实本地 Node HTTP server 和伪造的供应商完成响应，未发送真实照片或调用计费模型。覆盖健康/预检/来源拒绝/报告响应、伪造代理 IP 仍共享实例限流、超大分块与声明长度上传拒绝、客户端断开取消上游。
