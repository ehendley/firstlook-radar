# 初见雷达 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 完成可部署到 GitHub Pages、通过安全后端调用千问视觉模型的照片测评网站。

**Architecture:** public/ 为无构建依赖的静态 ES Modules 应用，worker/ 为 Cloudflare Workers。两端共享经过验证的报告协议。配置未就绪时仅主动提供示例。

**Tech Stack:** HTML/CSS/JavaScript Modules、Canvas、Node 22 原生测试、Cloudflare Workers、GitHub Actions。

**Spec:** docs/result-design.md

## Global Constraints

- GitHub Pages 仅托管前端，API Key 只在后端。
- 分析只描述本张照片的视觉呈现；不得伪装真实他人评价。
- 不存储照片或报告；模型文字以纯文本呈现。
- 明确区分示例与真实报告。

## Review Focus

- 上传失败后旧照片不得被误用；取消请求后迟到结果不得覆盖新会话。
- null 维度不得转成零分或填补成完整雷达。
- 模型输出、错误内容、图片中文字不得注入 HTML 或覆盖提示词。
- Origin 缺失/不允许、配置缺失、超大负载不得触发有费用的模型调用。
- 项目型 Pages 的子路径加载、窄屏布局和分享下载均正常。

### Task 1: 结果协议与后端

Files: public/lib/report.mjs、worker/index.mjs、worker/prompt.mjs、worker/wrangler.jsonc、tests/report.test.mjs、tests/worker.test.mjs。

Interfaces: 按 spec 数据协议导出共享常量和验证器。Worker 默认导出 {fetch(request,env)}，生产调用通过 env 的 API Key、Base URL、模型、允许 Origin 和原生限流绑定配置。

- [ ] 先写并运行协议异常、非图像/多人、缺配置、非法来源、限流、上游错误与成功报告的行为测试；先确认预期失败。
- [ ] 实现提示词、严格字段验证、负载限制、超时、限流和模型请求，运行测试确认通过。

### Task 2: 前端完整流程

Files: public/index.html、public/styles.css、public/app.mjs、public/lib/media.mjs、public/lib/share.mjs、public/config.json。

Interfaces: 消费共享协议；config.json 仅含 apiBaseUrl（公开URL，默认空）。上传发往 `${apiBaseUrl}/api/analyze`；示例使用 SAMPLE_REPORT 并标记 mode=demo。

- [ ] 完成首页、上传/授权/场景、取消、结果、雷达与分享流程。
- [ ] 用浏览器检查未配置、示例、上传错误、重新开始、下载和窄屏体验；发现问题后针对重要行为补回归测试。

### Task 3: 可交付与部署

Files: package.json、scripts/dev.mjs、scripts/build.mjs、.github/workflows/pages.yml、README.md、.gitignore。

- [ ] 本地服务和构建仅复制 public，排除 Worker、密钥及测试。
- [ ] 运行全部行为测试、语法检查、静态构建和桌面/移动预览。
- [ ] 委派独立审查；修复实质问题；提供用户注册/配置指引。
- [ ] 已授权 GitHub Pages 部署；在可用登录状态完成创建仓库/发布并验证URL。若账户或Key缺失，交付完整代码和预览并准确说明未完成部分，不声称部署或AI接通。
