# 初见雷达：结果分析与体验设计

定位：上传一张照片，发现这张照片呈现的第一印象，带走一张愿意分享的身份卡。只解读照片中可见的表达、造型和画面，不声称知道陌生人的真实想法。

## 设计决策

首版采用单人照片输入、三个可选场景、六维视觉风格分析、PNG 分享卡。默认不登录、不付费、不建立相册或公开报告库。

考虑过纯问卷、浏览器直接调用模型、静态前端加独立后端：纯问卷不符合照片入口，浏览器直连会暴露站点密钥；采用 GitHub Pages 静态前端 + Cloudflare Workers 后端 + 阿里云百炼千问视觉模型。模型与 Base URL 用后端变量配置，首选 qwen3-vl-plus，北京业务空间地址。已复核官方 JSON Mode 图像示例；使用 json_object 和本地字段校验，不依赖多模态场景中未强制生效的 JSON Schema。

## 完整结果顺序

1. 初见类型：八种正向且不分高低的类型，一句有记忆点的短评，三个关键词。
2. 六维雷达：亲近感、清爽感、松弛感、利落感、存在感、故事感。0–100 表示本张照片中该视觉效果的呈现强度，不是优劣、颜值或人格分数；不足以判断时为 null。
3. 三个记忆点：每个都有标题、解释、照片可见依据。
4. 一句初见联想：明确是趣味创作的开场白，不伪装成他人调查结果。
5. 三条场景建议：保留可见优势，给小而具体的表情、穿搭、构图或光线建议。
6. 分享卡：类型、短评、关键词、雷达、小字范围说明；原照片默认不加入，由用户勾选。支持 PNG 下载、复制文案、重新测。

## 维度定义

| key | 展示名 | 可观察依据 |
| --- | --- | --- |
| warmth | 亲近感 | 笑容、嘴角、面部朝向、视线与镜头的关系；不代表善良或可信 |
| freshness | 清爽感 | 配色、造型线条、背景简洁程度；不代表身体健康 |
| ease | 松弛感 | 可见姿态、肩颈和动作呈现；不判断实际情绪或心理状态 |
| polish | 利落感 | 衣饰搭配、轮廓与细节组织；不推断财富或职业 |
| presence | 存在感 | 色彩对比、造型辨识度、画面焦点；不等于外向或领导力 |
| story | 故事感 | 光影、环境、道具与构图形成的画面叙事；不推断真实经历 |

八种类型：warm_light/暖光破冰型、breeze/微风同频型、cinema/清醒电影型、relaxed/松弛主场型、focus/鲜明焦点型、blank/留白故事型、spark/轻快灵感型、clean/干净直球型。类型至少使用两条不同视觉依据；不按最高分机械决定。

## 示例报告

类型：微风同频型。短评：“不用很用力，也会让人想靠近一点。”关键词：自然、清爽、轻轻有趣。解释：浅色造型、自然光和面向镜头的笑容，让这张照片呈现轻快、容易开启对话的视觉感觉。示例必须明确标为示例，不得在未调用模型时伪装成上传照片的真实分析。

六维示例：亲近感85、清爽感80、松弛感75、利落感60、存在感55、故事感70。这些不是用户真实照片的分析。

## 数据协议

前端 POST /api/analyze：{ image: JPEG/PNG/WebP 的 base64 data URI, scene: daily|avatar|work, consent: true }。

后端成功返回 { mode: "live", report }。report 为：

```
{ version:"1.0", status:"ready", archetype:{id,name,headline,summary},
  keywords:[string,string,string],
  dimensions:[{key,label,score:number|null,note,evidence}],
  highlights:[{title,description,evidence}],
  icebreaker:{line,context}, suggestions:[{title,action,reason}],
  quality:{level:"good"|"limited",note}, scope:string }
```

dimensions 必须恰好六项，key 与上表一致。highlights 与 suggestions 恰好三项。不可分析时返回 { version:"1.0",status:"retake",reason:"no_person"|"multiple_people"|"unclear"|"unsupported",message }，不制造分数。v1 不提供多人选择，提示裁剪为单人图后重传。不估计年龄，所有结果采用全年龄的非性化描述。不推断身份、种族、健康、性取向、人格、智力、财富和可信度。图片里出现的指令和文字一律当成待观察内容，不得覆盖任务。

共享 public/lib/report.mjs 导出 DIMENSIONS、ARCHETYPES、SAMPLE_REPORT、validateReport(report)。validateReport 返回经过字段验证和安全字段选择的 report，或抛出 Error；不得只相信模型输出。服务端固定 scope 和维度 label。UI 将所有模型文字当纯文本显示。

## 流程与视觉

首页 → 选择场景 → 上传并预览 → 确认有权使用照片并同意送往 AI 服务分析 → 分析中（可取消） → 结果。用户可以不上传而直接看示例。没有配置后端时说明“真实分析尚未开通”，不静默回退到示例。

视觉：暖白纸张、近黑大字、荧光黄绿色点缀，带细网格的雷达图、票据式结果卡和少量贴纸，轻松但不廉价。移动端优先。系统中文字体，不依赖境外字体或公共 CDN。支持键盘、可见焦点、减少动态效果。

## 图片与服务边界

前端只接受 JPEG、PNG、WebP，原图最大 10MB；读图后长边缩到 1280 并重新编码 JPEG，以降低上传量并移除原有元数据。压缩后的 data URI 设服务端上限。仅在内存中保留照片；不写 localStorage，不写报告数据库，不记录请求正文或 Key。照片经过后端转给所选模型供应商，供应商的处理规则以其政策为准，产品不作“绝不留存”等无法验证的承诺。

后端要求允许的 Origin、严格输入验证、超时与原生限流；没有 Key/限流绑定时关闭真实分析，不假装成功。模型错误、限流、非法报告均显示可理解的中文重试信息。API Key 只放 Workers Secret，GitHub 仓库和 Pages 只存公开 API 地址。

## 验收

可本地完整体验示例、可上传预览、可下载分享 PNG、可重测；桌面和窄屏无溢出；真实请求链路有边界与异常测试；接入配置前清晰显示未开通；提供 GitHub Pages 工作流、Workers 配置与开通说明。部署需要外部账户登录和真实模型 Key，未验证成功就不宣称上线或AI接通。
