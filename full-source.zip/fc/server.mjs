import { createServer } from 'node:http';
import { pathToFileURL } from 'node:url';
import { createHandler, MAX_REQUEST_BYTES } from '../worker/index.mjs';

class TooLarge extends Error {}

// No FC client-IP header has been relied on here. All visitors share this instance budget.
function instanceLimiter(now) {
  let accepted = [];
  return { async limit() {
    const time = now();
    accepted = accepted.filter(at => at > time - 60000);
    if (accepted.length >= 3) return { success: false };
    accepted.push(time);
    return { success: true };
  } };
}

function readBody(request, signal) {
  if (Number(request.headers['content-length']) > MAX_REQUEST_BYTES) return Promise.reject(new TooLarge());
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    const cleanup = () => {
      request.off('data', data); request.off('end', end); request.off('error', error);
      signal.removeEventListener('abort', abort);
    };
    const fail = reason => { cleanup(); reject(reason); };
    const data = chunk => {
      size += chunk.length;
      if (size > MAX_REQUEST_BYTES) { fail(new TooLarge()); request.resume(); return; }
      chunks.push(chunk);
    };
    const end = () => { cleanup(); resolve(Buffer.concat(chunks, size)); };
    const error = reason => fail(reason);
    const abort = () => fail(new DOMException('Aborted', 'AbortError'));
    if (signal.aborted) { abort(); return; }
    signal.addEventListener('abort', abort, { once: true });
    request.on('data', data); request.once('end', end); request.once('error', error);
  });
}

function adapterError(status, env, origin) {
  const tooLarge = status === 413;
  const allowed = typeof env.ALLOWED_ORIGINS === 'string' && env.ALLOWED_ORIGINS.split(',').map(s => s.trim()).includes(origin);
  return new Response(JSON.stringify({ error: {
    code: tooLarge ? 'TOO_LARGE' : 'UNAVAILABLE',
    message: tooLarge ? '照片数据太大，请压缩后重试。' : '分析服务暂不可用，请稍后重试。',
  } }), { status, headers: {
    'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff', Vary: 'Origin',
    ...(allowed && origin ? { 'Access-Control-Allow-Origin': origin } : {}),
  } });
}

export function createFcServer({ env = process.env, fetchImpl = globalThis.fetch, timeoutMs = 45000, now = Date.now } = {}) {
  const handle = createHandler({ fetchImpl, timeoutMs });
  const config = {
    ALLOWED_ORIGINS: env.ALLOWED_ORIGINS, DASHSCOPE_API_KEY: env.DASHSCOPE_API_KEY,
    QWEN_BASE_URL: env.QWEN_BASE_URL, QWEN_MODEL: env.QWEN_MODEL,
    ANALYZE_RATE_LIMITER: instanceLimiter(now),
  };
  const server = createServer(async (incoming, outgoing) => {
    const controller = new AbortController();
    const abort = () => controller.abort();
    const disconnected = () => { if (!outgoing.writableFinished) abort(); };
    incoming.once('aborted', abort); incoming.once('error', abort); outgoing.once('close', disconnected);
    try {
      let response;
      try {
        const body = await readBody(incoming, controller.signal);
        controller.signal.throwIfAborted();
        const headers = new Headers();
        for (const [key, value] of Object.entries(incoming.headers)) {
          if (Array.isArray(value)) value.forEach(part => headers.append(key, part));
          else if (value !== undefined) headers.set(key, value);
        }
        // Never trust client-supplied proxy IPs. A constant gives the shared handler one limiter key.
        headers.delete('CF-Connecting-IP'); headers.set('CF-Connecting-IP', '0.0.0.0');
        const request = new Request(new URL(incoming.url, 'http://fc.local'), {
          method: incoming.method, headers, signal: controller.signal,
          ...(!['GET', 'HEAD'].includes(incoming.method) && body.length ? { body } : {}),
        });
        response = await handle(request, config);
      } catch (error) {
        if (controller.signal.aborted) return;
        const status = error instanceof TooLarge ? 413 : 503;
        response = adapterError(status, config, incoming.headers.origin);
        incoming.resume();
      }
      if (controller.signal.aborted || outgoing.destroyed) return;
      outgoing.statusCode = response.status;
      for (const [key, value] of response.headers) outgoing.setHeader(key, value);
      outgoing.end(Buffer.from(await response.arrayBuffer()));
    } catch {
      // No request body, credential or upstream error is written to logs or the connection.
      if (!outgoing.destroyed) outgoing.destroy();
    } finally {
      incoming.off('aborted', abort); incoming.off('error', abort); outgoing.off('close', disconnected);
    }
  });
  server.headersTimeout = 15000;
  server.requestTimeout = 90000;
  return server;
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  createFcServer().listen(9000, '0.0.0.0');
}
