// Browser-upload friendly deployment: keep all frontend modules in one directory.
// The source project retains its original structure; no secrets are copied.
import { readFile, writeFile, mkdir, rm, readdir, copyFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { join } from 'node:path';

const root = fileURLToPath(new URL('..', import.meta.url));
const destination = join(root, 'pages');
await rm(destination, { recursive: true, force: true });
await mkdir(destination, { recursive: true });
for (const name of ['index.html', 'styles.css', 'config.json']) await copyFile(join(root, 'public', name), join(destination, name));
const app = (await readFile(join(root, 'public', 'app.mjs'), 'utf8')).replaceAll("from './lib/", "from './");
await writeFile(join(destination, 'app.mjs'), app);
for (const name of await readdir(join(root, 'public', 'lib'))) {
  if (name.endsWith('.mjs')) await copyFile(join(root, 'public', 'lib', name), join(destination, name));
}
await writeFile(join(destination, '.nojekyll'), '\n');
console.log(`GitHub Pages upload directory: ${destination}`);
