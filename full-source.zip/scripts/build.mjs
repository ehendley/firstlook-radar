import { cp, mkdir, rm, access } from 'node:fs/promises';
import { lstatSync } from 'node:fs';
import { resolve, relative, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

export async function buildStatic(projectRoot = resolve(fileURLToPath(new URL('..', import.meta.url)))) {
  const source = resolve(projectRoot, 'public');
  const destination = resolve(projectRoot, 'dist');
  await access(resolve(source, 'index.html'));
  await rm(destination, { recursive: true, force: true });
  await mkdir(destination, { recursive: true });
  await cp(source, destination, {
    recursive: true,
    filter: (path) => !relative(source, path).split(sep).some(part => part.startsWith('.')) && !lstatSync(path).isSymbolicLink(),
  });
  return destination;
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const path = await buildStatic();
  console.log(`Static build ready: ${path}`);
}
