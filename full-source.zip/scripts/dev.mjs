import { createServer } from 'node:http';
import { readFile, realpath, stat } from 'node:fs/promises';
import { resolve, sep, extname } from 'node:path';
import { fileURLToPath } from 'node:url';

const TYPES = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.webp': 'image/webp', '.ico': 'image/x-icon' };

export function createStaticServer(publicRoot) {
  const root = resolve(publicRoot);
  return createServer(async (request, response) => {
    const fail = (status) => { response.writeHead(status, { 'content-type': 'text/plain; charset=utf-8', 'cache-control': 'no-store' }); response.end(status === 404 ? 'Not found' : 'Method not allowed'); };
    if (!['GET', 'HEAD'].includes(request.method)) return fail(405);
    try {
      const pathname = decodeURIComponent(new URL(request.url, 'http://localhost').pathname);
      if (pathname.includes('\0') || pathname.split(/[\\/]/).some(part => part.startsWith('.'))) return fail(404);
      let target = resolve(root, `.${pathname}`);
      if (target !== root && !target.startsWith(root + sep)) return fail(404);
      const info = await stat(target);
      if (info.isDirectory()) target = resolve(target, 'index.html');
      target = await realpath(target);
      if (!target.startsWith((await realpath(root)) + sep)) return fail(404);
      const content = await readFile(target);
      response.writeHead(200, { 'content-type': TYPES[extname(target)] || 'application/octet-stream', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' });
      response.end(request.method === 'HEAD' ? undefined : content);
    } catch { fail(404); }
  });
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const root = fileURLToPath(new URL('../public', import.meta.url));
  const port = Number(process.env.PORT || 4173);
  const server = createStaticServer(root);
  server.listen(port, '127.0.0.1', () => console.log(`Local: http://127.0.0.1:${port}`));
  for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, () => server.close(() => process.exit(0)));
}
