import test from 'node:test';
import assert from 'node:assert/strict';
import { createServiceConnection } from '../public/lib/connection.mjs';

function connect(options) {
  return createServiceConnection({ configUrl: 'https://example.test/config.json', ...options });
}
const config = () => Response.json({ apiBaseUrl: 'https://api.example.test' });

test('a failed health check can reconnect without sending a photo or an analysis request', async () => {
  let available = false;
  const requests = [];
  const connection = connect({ fetchImpl: async (url, options) => {
    requests.push({url: String(url), method: options?.method || 'GET'});
    if (String(url).endsWith('config.json')) return config();
    if (!available) throw new TypeError('network unavailable');
    return Response.json({configured: true});
  }});
  assert.equal((await connection.check()).status, 'unavailable');
  available = true;
  assert.equal((await connection.check()).status, 'ready');
  assert.equal(connection.state.apiBase, 'https://api.example.test');
  assert.deepEqual(requests, [
    {url:'https://example.test/config.json',method:'GET'},
    {url:'https://api.example.test/api/health',method:'GET'},
    {url:'https://example.test/config.json',method:'GET'},
    {url:'https://api.example.test/api/health',method:'GET'},
  ]);
});

test('simultaneous recovery events share one connection check', async () => {
  let release;
  let calls = 0;
  const delayedConfig = new Promise(resolve => { release = resolve; });
  const connection = connect({ fetchImpl: async url => {
    calls++;
    return String(url).endsWith('config.json') ? delayedConfig : Response.json({configured:true});
  }});
  const first = connection.check();
  const second = connection.check();
  assert.equal(connection.state.status, 'checking');
  release(config());
  assert.equal((await first).status, 'ready');
  assert.equal((await second).status, 'ready');
  assert.equal(calls, 2);
});

test('an unconfigured backend remains disabled and is distinct from an unreachable backend', async () => {
  const connection = connect({fetchImpl: async url => String(url).endsWith('config.json') ? config() : Response.json({configured:false})});
  assert.equal((await connection.check()).status, 'unconfigured');
});

test('a connection timeout settles, permits manual recovery, and never starts a background retry loop', async () => {
  let stalled = true;
  let calls = 0;
  const connection = connect({ timeoutMs:10, fetchImpl: async (url, options) => {
    calls++;
    if (String(url).endsWith('config.json')) return config();
    if (!stalled) return Response.json({configured:true});
    return new Promise((resolve, reject) => options.signal.addEventListener('abort', () => reject(new DOMException('aborted', 'AbortError')), {once:true}));
  }});
  assert.equal((await connection.check()).status, 'timeout');
  assert.equal(calls, 2);
  stalled = false;
  assert.equal((await connection.check()).status, 'ready');
  assert.equal(calls, 4);
});

test('repeated automatic recovery events are throttled but manual reconnect is immediate', async () => {
  let time = 0;
  let calls = 0;
  const connection = connect({now:() => time, fetchImpl: async () => { calls++; throw new TypeError('offline'); }});
  await connection.check();
  time = 2000;
  await connection.check({automatic:true});
  await connection.check({automatic:true});
  assert.equal(calls, 1);
  await connection.check();
  assert.equal(calls, 2);
  time = 13000;
  await connection.check({automatic:true});
  assert.equal(calls, 3);
});
