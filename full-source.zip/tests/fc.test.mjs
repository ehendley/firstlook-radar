import test from 'node:test';
import assert from 'node:assert/strict';
import { request as httpRequest } from 'node:http';
import { createFcServer } from '../fc/server.mjs';
import { MAX_REQUEST_BYTES } from '../worker/index.mjs';
import { SAMPLE_REPORT } from '../public/lib/report.mjs';

const ORIGIN = 'https://example.github.io';
const env = {
  ALLOWED_ORIGINS: ORIGIN, DASHSCOPE_API_KEY: 'fc-test-secret',
  QWEN_BASE_URL: 'https://workspace.cn-beijing.maas.aliyuncs.com/compatible-mode/v1',
  QWEN_MODEL: 'qwen3-vl-plus',
};
const payload = { image: 'data:image/jpeg;base64,/9j/AAAB/9k=', scene: 'daily', consent: true };
const completion = () => new Response(JSON.stringify({ choices: [{ finish_reason: 'stop', message: {
  role: 'assistant', content: JSON.stringify({ result: SAMPLE_REPORT }),
} }] }), { headers: { 'content-type': 'application/json' } });

async function start(t, options = {}) {
  const server = createFcServer({ env, ...options });
  await new Promise((resolve, reject) => { server.once('error', reject); server.listen(0, '127.0.0.1', resolve); });
  t.after(async () => { server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); });
  return `http://127.0.0.1:${server.address().port}`;
}
const analyze = (base, extraHeaders = {}) => fetch(`${base}/api/analyze`, {
  method: 'POST', headers: { Origin: ORIGIN, 'Content-Type': 'application/json', ...extraHeaders }, body: JSON.stringify(payload),
});

// A missing Node Request/Response bridge would lose status, CORS or JSON bodies.
test('FC HTTP adapter preserves shared health, preflight, origin rejection and live JSON behavior', async t => {
  let calls = 0;
  const base = await start(t, { fetchImpl: async () => { calls++; return completion(); } });
  const health = await fetch(`${base}/api/health`, { headers: { Origin: ORIGIN } });
  assert.equal(health.status, 200);
  assert.deepEqual(await health.json(), { configured: true });
  assert.equal(health.headers.get('access-control-allow-origin'), ORIGIN);
  const preflight = await fetch(`${base}/api/analyze`, { method: 'OPTIONS', headers: {
    Origin: ORIGIN, 'Access-Control-Request-Method': 'POST', 'Access-Control-Request-Headers': 'content-type',
  } });
  assert.equal(preflight.status, 204);
  assert.equal(preflight.headers.get('access-control-allow-methods'), 'POST, OPTIONS');
  const denied = await analyze(base, { Origin: 'https://evil.test' });
  assert.equal(denied.status, 403);
  assert.equal(denied.headers.get('access-control-allow-origin'), null);
  assert.equal(calls, 0);
  const result = await analyze(base);
  assert.equal(result.status, 200);
  assert.equal(result.headers.get('cache-control'), 'no-store');
  assert.equal(result.headers.get('access-control-allow-origin'), ORIGIN);
  assert.deepEqual(await result.json(), { mode: 'live', report: SAMPLE_REPORT });
  assert.equal(calls, 1);
});

// Trusting a supplied CF header would let clients evade the instance-wide limiter.
test('FC uses one instance-wide 3-per-minute budget even when the client changes forged proxy IPs', async t => {
  let now = 1000, calls = 0;
  const base = await start(t, { now: () => now, fetchImpl: async () => { calls++; return completion(); } });
  for (const ip of ['203.0.113.1', '203.0.113.2', 'not-an-ip']) {
    const response = await analyze(base, { 'CF-Connecting-IP': ip, 'X-Forwarded-For': ip });
    assert.equal(response.status, 200);
    await response.arrayBuffer();
  }
  const limited = await analyze(base, { 'CF-Connecting-IP': '203.0.113.4' });
  assert.equal(limited.status, 429);
  assert.equal(limited.headers.get('retry-after'), '60');
  assert.equal(calls, 3);
  now = 61000;
  const recovered = await analyze(base);
  assert.equal(recovered.status, 200);
  await recovered.arrayBuffer();
  assert.equal(calls, 4);
});

// Checking Content-Length alone would allow an unlimited chunked body to fill memory.
test('FC rejects oversized chunked and declared request bodies before calling the model', async t => {
  let calls = 0;
  const base = await start(t, { fetchImpl: async () => { calls++; return completion(); } });
  const response = await new Promise((resolve, reject) => {
    const request = httpRequest(`${base}/api/analyze`, { method: 'POST', headers: {
      Origin: ORIGIN, 'Content-Type': 'application/json', 'Transfer-Encoding': 'chunked',
    } }, response => {
      let body = '';
      response.setEncoding('utf8'); response.on('data', chunk => { body += chunk; });
      response.on('end', () => resolve({ status: response.statusCode, headers: response.headers, body }));
    });
    request.on('error', reject);
    request.end(Buffer.alloc(MAX_REQUEST_BYTES + 1, 120));
  });
  assert.equal(response.status, 413);
  assert.equal(response.headers['access-control-allow-origin'], ORIGIN);
  assert.equal(JSON.parse(response.body).error.code, 'TOO_LARGE');
  const declared = await fetch(`${base}/api/analyze`, { method: 'POST', headers: {
    Origin: ORIGIN, 'Content-Type': 'application/json',
  }, body: 'x'.repeat(MAX_REQUEST_BYTES + 1) });
  assert.equal(declared.status, 413);
  assert.equal(calls, 0);
});

// Missing response-close propagation would keep a billable upstream call alive after mobile disconnects.
test('FC client disconnect aborts the shared handler upstream request', async t => {
  let markStarted, markAborted;
  const started = new Promise(resolve => { markStarted = resolve; });
  const aborted = new Promise(resolve => { markAborted = resolve; });
  const base = await start(t, { fetchImpl: async (_url, { signal }) => {
    markStarted();
    return new Promise((_resolve, reject) => {
      signal.addEventListener('abort', () => { markAborted(); reject(new DOMException('Aborted', 'AbortError')); }, { once: true });
    });
  } });
  const request = httpRequest(`${base}/api/analyze`, { method: 'POST', headers: { Origin: ORIGIN, 'Content-Type': 'application/json' } });
  request.on('error', () => {});
  request.end(JSON.stringify(payload));
  await started;
  request.destroy();
  await Promise.race([aborted, new Promise((_resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('upstream was not aborted after disconnect')), 1000); timer.unref();
  })]);
});
