import test from 'node:test';
import assert from 'node:assert/strict';
import { validateImageFile, validatePreparedSize, fitWithin, containRect, createRequestGate } from '../public/lib/media.mjs';

test('image validation accepts supported formats up to 10 MiB and rejects other or empty files', () => {
  for (const type of ['image/jpeg', 'image/png', 'image/webp']) {
    assert.doesNotThrow(() => validateImageFile({type, size: 10 * 1024 * 1024}));
  }
  for (const file of [{type:'image/svg+xml',size:300}, {type:'image/heic',size:300}, {type:'image/jpeg',size:0}, {type:'image/jpeg',size:10 * 1024 * 1024 + 1}]) {
    assert.throws(() => validateImageFile(file), /照片|图片|10MB/);
  }
});

test('compression preserves aspect ratio and never enlarges small photos', () => {
  assert.deepEqual(fitWithin(4000,3000), {width:1280,height:960});
  assert.deepEqual(fitWithin(3000,4000), {width:960,height:1280});
  assert.deepEqual(fitWithin(640,480), {width:640,height:480});
  assert.throws(() => fitWithin(0,480));
});

test('share photos preserve every edge and center portrait and landscape photos within the card', () => {
  assert.deepEqual(containRect(800,1200,870,480), {x:275,y:0,width:320,height:480});
  assert.deepEqual(containRect(1200,800,870,480), {x:75,y:0,width:720,height:480});
  assert.deepEqual(containRect(800,800,870,480), {x:195,y:0,width:480,height:480});
  assert.throws(() => containRect(0,1200,870,480));
});

test('cancelled and superseded async requests cannot replace the current result', () => {
  const gate=createRequestGate();
  const first=gate.begin();
  assert.equal(gate.isCurrent(first),true);
  gate.cancel();
  assert.equal(gate.isCurrent(first),false);
  const second=gate.begin();
  const third=gate.begin();
  assert.equal(gate.isCurrent(second),false);
  assert.equal(gate.isCurrent(third),true);
});

test('prepared photos exceeding the API limit are rejected before sending', () => {
  assert.doesNotThrow(() => validatePreparedSize(3 * 1024 * 1024));
  assert.throws(() => validatePreparedSize(3 * 1024 * 1024 + 1), /照片|3MB/);
});
