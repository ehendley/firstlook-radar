import test from 'node:test';
import assert from 'node:assert/strict';
import { DIMENSIONS, ARCHETYPES, SAMPLE_REPORT, validateReport } from '../public/lib/report.mjs';

test('sample is a complete report with six unique dimensions and eight possible types', () => {
  const result = validateReport(SAMPLE_REPORT);
  assert.equal(result.status, 'ready');
  assert.equal(result.dimensions.length, 6);
  assert.equal(new Set(DIMENSIONS.map(d => d.key)).size, 6);
  assert.equal(ARCHETYPES.length, 8);
  assert.equal(result.highlights.length, 3);
  assert.equal(result.suggestions.length, 3);
});

test('keeps unknown scores null and fixes server-owned labels, names and scope', () => {
  const input = structuredClone(SAMPLE_REPORT);
  input.dimensions[0].score = null;
  input.dimensions[0].label = 'hacked';
  input.archetype.name = 'hacked';
  input.scope = 'hacked';
  input.html = '<script>bad()</script>';
  input.dimensions[0].html = 'bad';
  const result = validateReport(input);
  assert.equal(result.dimensions[0].score, null);
  assert.equal(result.dimensions[0].label, '亲近感');
  assert.equal(result.archetype.name, '微风同频型');
  assert.notEqual(result.scope, 'hacked');
  assert.equal(result.html, undefined);
  assert.equal(result.dimensions[0].html, undefined);
});

test('rejects incomplete, duplicated, out-of-range or nonfinite dimensions and unknown type', () => {
  for (const mutate of [
    r => r.dimensions.pop(),
    r => { r.dimensions[1].key = r.dimensions[0].key; },
    r => { r.dimensions[0].score = 101; },
    r => { r.dimensions[0].score = NaN; },
    r => { r.dimensions[0].score = '70'; },
    r => { r.archetype.id = 'unknown'; },
    r => { r.highlights = []; },
    r => { r.keywords = ['a', 'b']; },
    r => { r.archetype.summary = ' '; },
    r => { r.icebreaker.line = 'a'.repeat(401); },
    r => { r.quality.level = 'perfect'; },
    r => { r.version = '2'; },
  ]) {
    const input = structuredClone(SAMPLE_REPORT);
    mutate(input);
    assert.throws(() => validateReport(input));
  }
});

test('retake never carries invented scores and accepts only recognized reasons', () => {
  for (const reason of ['no_person', 'multiple_people', 'unclear', 'unsupported']) {
    const result = validateReport({version:'1.0', status:'retake', reason, message:'请换一张清晰的单人照片。', dimensions:SAMPLE_REPORT.dimensions});
    assert.deepEqual(Object.keys(result).sort(), ['message', 'reason', 'status', 'version']);
  }
  for (const input of [null, [], {}, {version:'1.0',status:'retake',reason:'other',message:'换照片'}]) assert.throws(() => validateReport(input));
});
