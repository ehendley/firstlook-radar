import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, mkdir, writeFile, readFile, readdir, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { buildStatic } from '../scripts/build.mjs';
import { createStaticServer } from '../scripts/dev.mjs';

test('build publishes only the static application, excluding hidden files and backend secrets', async () => {
  const root = await mkdtemp(join(tmpdir(), 'firstlook-build-'));
  try {
    await mkdir(join(root, 'public', 'lib'), { recursive: true });
    await mkdir(join(root, 'worker'));
    await writeFile(join(root, 'public', 'index.html'), '<h1>初见雷达</h1>');
    await writeFile(join(root, 'public', 'lib', 'ui.mjs'), 'export const title="初见雷达"');
    await writeFile(join(root, 'public', '.env'), 'NEVER_PUBLISH=private');
    await writeFile(join(root, 'worker', '.dev.vars'), 'DASHSCOPE_API_KEY=private');
    await buildStatic(root);
    assert.deepEqual((await readdir(join(root, 'dist'))).sort(), ['index.html', 'lib']);
    assert.equal(await readFile(join(root, 'dist', 'index.html'), 'utf8'), '<h1>初见雷达</h1>');
    assert.equal(await readFile(join(root, 'dist', 'lib', 'ui.mjs'), 'utf8'), 'export const title="初见雷达"');
  } finally { await rm(root, { recursive: true, force: true }); }
});

test('preview serves modules with JavaScript MIME and never serves dotfiles or paths outside public', async () => {
  const root = await mkdtemp(join(tmpdir(), 'firstlook-server-'));
  let server;
  try {
    await mkdir(join(root, 'public'));
    await writeFile(join(root, 'public', 'index.html'), '<h1>初见雷达</h1>');
    await writeFile(join(root, 'public', 'app.mjs'), 'export const ok=true;');
    await writeFile(join(root, 'public', '.env'), 'private');
    await writeFile(join(root, 'secret.txt'), 'private');
    server = createStaticServer(join(root, 'public'));
    await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
    const base = `http://127.0.0.1:${server.address().port}`;
    assert.equal(await (await fetch(`${base}/`)).text(), '<h1>初见雷达</h1>');
    const moduleResponse = await fetch(`${base}/app.mjs`);
    assert.match(moduleResponse.headers.get('content-type'), /javascript/);
    assert.equal(moduleResponse.status, 200);
    assert.equal((await fetch(`${base}/.env`)).status, 404);
    assert.equal((await fetch(`${base}/%2e%2e%2fsecret.txt`)).status, 404);
    assert.equal((await fetch(`${base}/worker/.dev.vars`)).status, 404);
  } finally {
    if (server) await new Promise(resolve => server.close(resolve));
    await rm(root, { recursive: true, force: true });
  }
});
