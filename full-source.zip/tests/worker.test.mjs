import test, { mock } from 'node:test';
import assert from 'node:assert/strict';
import { createHandler, MAX_REQUEST_BYTES } from '../worker/index.mjs';
import { SAMPLE_REPORT } from '../public/lib/report.mjs';

const ORIGIN = 'https://example.github.io';
const image = 'data:image/jpeg;base64,/9j/AAAB/9k=';
const payload = {image,scene:'daily',consent:true};
const env = (overrides = {}) => ({
  ALLOWED_ORIGINS: ORIGIN, DASHSCOPE_API_KEY:'test-secret',
  QWEN_BASE_URL:'https://workspace.cn-beijing.maas.aliyuncs.com/compatible-mode/v1',
  ANALYZE_RATE_LIMITER: {limit: async () => ({success:true})}, ...overrides,
});
const request = (body = payload, headers = {}, method = 'POST', path = '/api/analyze') => new Request(`https://api.example.com${path}`, {
  method, headers: {'Content-Type':'application/json',Origin:ORIGIN,'CF-Connecting-IP':'203.0.113.5',...headers},
  ...(method === 'POST' ? {body: typeof body === 'string' ? body : JSON.stringify(body)} : {}),
});
const completion = report => new Response(JSON.stringify({choices:[{finish_reason:'stop',message:{role:'assistant',content:JSON.stringify({result:report})}}]}), {headers:{'content-type':'application/json'}});

test('health reveals only configuration and OPTIONS allows only exact configured origins', async () => {
  const upstream = mock.fn(async () => completion(SAMPLE_REPORT));
  const handler = createHandler({fetchImpl:upstream});
  const health = await handler(request(null,{},'GET','/api/health'), env());
  assert.equal(health.status,200);
  assert.deepEqual(await health.json(), {configured:true});
  assert.equal(health.headers.get('Cache-Control'), 'no-store');
  assert.deepEqual(await (await handler(request(null,{},'GET','/api/health'), env({ANALYZE_RATE_LIMITER:undefined}))).json(), {configured:false});
  const preflight = await handler(request(null,{'Access-Control-Request-Method':'POST','Access-Control-Request-Headers':'content-type'},'OPTIONS'),env());
  assert.equal(preflight.status,204);
  assert.equal(preflight.headers.get('Access-Control-Allow-Origin'), ORIGIN);
  const rejected = await handler(request(null,{Origin:'https://example.github.io.evil.test'},'OPTIONS'),env());
  assert.equal(rejected.status,403);
  assert.equal(rejected.headers.get('Access-Control-Allow-Origin'),null);
  assert.equal(upstream.mock.callCount(),0);
});

test('missing origin, disallowed origin and absent configuration fail before upstream', async () => {
  const upstream = mock.fn(async () => completion(SAMPLE_REPORT));
  const handler = createHandler({fetchImpl:upstream});
  for (const [headers, config, expectedStatus] of [
    [{Origin:''},env(),403], [{Origin:'null'},env(),403], [{Origin:'https://evil.test'},env(),403],
    [{},env({ALLOWED_ORIGINS:''}),403], [{},env({DASHSCOPE_API_KEY:''}),503],
    [{},env({QWEN_BASE_URL:''}),503], [{},env({ANALYZE_RATE_LIMITER:undefined}),503],
    [{},env({QWEN_BASE_URL:'http://workspace.cn-beijing.maas.aliyuncs.com/compatible-mode/v1'}),503],
    [{'CF-Connecting-IP':''},env(),503],
  ]) {
    assert.equal((await handler(request(payload,headers),config)).status,expectedStatus);
    assert.equal(upstream.mock.callCount(),0);
  }
});

test('invalid consent, scenes, URLs, MIME/magic mismatch, bad base64, oversized and extra request fields are rejected', async () => {
  const upstream = mock.fn(async () => completion(SAMPLE_REPORT));
  const handler = createHandler({fetchImpl:upstream});
  for (const bad of [
    {...payload,consent:false}, {...payload,scene:'date'}, {...payload,model:'other'},
    {...payload,image:'https://evil.test/a.jpg'}, {...payload,image:'data:image/svg+xml;base64,PHN2Zz4='},
    {...payload,image:'data:image/png;base64,/9j/AAAB/9k='}, {...payload,image:'data:image/jpeg;base64,###='},
    {...payload,image:'data:image/jpeg;base64,'}, null, [], '{bad',
  ]) {
    assert.equal((await handler(request(bad),env())).status,400);
    assert.equal(upstream.mock.callCount(),0);
  }
  assert.equal((await handler(request('x'.repeat(MAX_REQUEST_BYTES+1)),env())).status,413);
  assert.equal(upstream.mock.callCount(),0);
  assert.equal((await handler(request(payload,{'Content-Type':'text/plain'}),env())).status,415);
  assert.equal(upstream.mock.callCount(),0);
});

test('native limiter denial and outage fail closed and use a nonempty per-client key', async () => {
  const upstream = mock.fn(async () => completion(SAMPLE_REPORT));
  const handler = createHandler({fetchImpl:upstream});
  let key;
  const limited = await handler(request(),env({ANALYZE_RATE_LIMITER:{limit:async args => {key=args.key; return {success:false};}}}));
  assert.equal(limited.status,429);
  assert.equal(limited.headers.get('Retry-After'),'60');
  assert.ok(typeof key === 'string' && key.length > 10);
  assert.equal(key.includes('203.0.113.5'),false);
  assert.equal(upstream.mock.callCount(),0);
  assert.equal((await handler(request(),env({ANALYZE_RATE_LIMITER:{limit:async () => {throw new Error('secret');}}}))).status,503);
  assert.equal(upstream.mock.callCount(),0);
});

test('successful requests use configured Qwen, image-compatible JSON mode and only one data URI', async () => {
  let captured;
  const handler = createHandler({fetchImpl:async (url, options) => { captured={url,options}; return completion(SAMPLE_REPORT); }});
  const response = await handler(request(),env());
  assert.equal(response.status,200);
  const result = await response.json();
  assert.equal(result.mode,'live');
  assert.equal(result.report.archetype.id,'breeze');
  assert.equal(captured.url,'https://workspace.cn-beijing.maas.aliyuncs.com/compatible-mode/v1/chat/completions');
  assert.equal(captured.options.headers.Authorization,'Bearer test-secret');
  assert.equal(captured.options.redirect,'manual');
  const body=JSON.parse(captured.options.body);
  assert.equal(body.model,'qwen3-vl-plus');
  assert.equal(body.enable_thinking,false);
  assert.equal(body.stream,false);
  assert.equal(body.max_tokens,undefined);
  assert.deepEqual(body.response_format,{type:'json_object'});
  assert.equal(body.messages[1].content.filter(c=>c.type==='image_url').length,1);
  assert.equal(body.messages[1].content.find(c=>c.type==='image_url').image_url.url,image);
  assert.ok(captured.options.signal instanceof AbortSignal);
});

test('upstream redirects are rejected without forwarding credentials to another destination', async () => {
  const upstream = mock.fn(async () => new Response(null, {status:302,headers:{Location:'https://other.example/redirect'}}));
  const response = await createHandler({fetchImpl:upstream})(request(),env());
  assert.equal(response.status,502);
  assert.equal((await response.json()).error.code,'UPSTREAM_ERROR');
  assert.equal(upstream.mock.callCount(),1);
  assert.equal(upstream.mock.calls[0].arguments[1].redirect,'manual');
});

test('retake reasons never become manufactured scores and null scores stay null', async () => {
  for (const reason of ['no_person','multiple_people','unclear']) {
    const handler=createHandler({fetchImpl:async()=>completion({version:'1.0',status:'retake',reason,message:'请重新上传单人清晰照片。'})});
    const result=await (await handler(request(),env())).json();
    assert.equal(result.report.status,'retake');
    assert.equal(result.report.dimensions,undefined);
  }
  const report=structuredClone(SAMPLE_REPORT); report.dimensions[0].score=null;
  const result=await (await createHandler({fetchImpl:async()=>completion(report)})(request(),env())).json();
  assert.equal(result.report.dimensions[0].score,null);
});

test('upstream status, rejection, malformed JSON, invalid report and network failure never leak upstream content', async () => {
  for (const fetchImpl of [
    async()=>new Response('private-secret-upstream',{status:401}),
    async()=>new Response('private-secret-upstream',{status:429}),
    async()=>new Response('private-secret-upstream',{status:500}),
    async()=>new Response('not JSON private-secret-upstream'),
    async()=>new Response(JSON.stringify({choices:[{message:{refusal:'private-secret-upstream'}}]})),
    async()=>completion({version:'1.0',status:'ready'}),
    async()=>{throw new Error('private-secret-upstream');},
  ]) {
    const response=await createHandler({fetchImpl})(request(),env());
    assert.ok(response.status>=400);
    const body=await response.text();
    assert.equal(body.includes('private-secret-upstream'),false);
    assert.equal(body.includes('test-secret'),false);
    assert.ok(/[\u4e00-\u9fff]/u.test(body));
  }
});

test('upstream timeout produces a safe retry response', async () => {
  const handler=createHandler({timeoutMs:5,fetchImpl:async (_url,{signal}) => new Promise((_resolve,reject)=> {
    signal.addEventListener('abort',()=>reject(new DOMException('Aborted','AbortError')),{once:true});
  })});
  const response=await handler(request(),env());
  assert.equal(response.status,504);
  assert.ok((await response.json()).error.message.includes('超时'));
});

test('incoming cancellation aborts the upstream signal and rejects a late successful completion', async () => {
  const client = new AbortController();
  let upstreamSignal, finish;
  let markStarted;
  const started = new Promise(resolve => { markStarted = resolve; });
  const handler = createHandler({ fetchImpl: async (_url, {signal}) => {
    upstreamSignal = signal;
    markStarted();
    return new Promise(resolve => { finish = () => resolve(completion(SAMPLE_REPORT)); });
  } });
  const pending = handler(new Request(request(), {signal: client.signal}), env());
  await started;
  client.abort();
  assert.equal(upstreamSignal.aborted, true);
  // A completed fetch can race with cancellation; it must not become a successful report.
  finish();
  const response = await pending;
  assert.notEqual(response.status, 200);
  const result = await response.json();
  assert.equal(result.report, undefined);
  assert.equal(result.error.code, 'CANCELLED');
});
