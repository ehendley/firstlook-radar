import { validateReport } from '../public/lib/report.mjs';
import { REPORT_RESPONSE_FORMAT, SYSTEM_PROMPT, userMessage } from './prompt.mjs';

const MAX_IMAGE_BYTES = 3 * 1024 * 1024;
export const MAX_REQUEST_BYTES = 4 * 1024 * 1024 + 4096;
const MAX_RESPONSE_BYTES = 96 * 1024;

class SafeError extends Error {
  constructor(status, code, message) { super(message); this.status = status; this.code = code; }
}
const invalid = () => new SafeError(400, 'INVALID_REQUEST', '请上传 JPEG、PNG 或 WebP 单人照片，选择有效场景并确认授权。');

function origins(env) {
  if (typeof env.ALLOWED_ORIGINS !== 'string') return [];
  return env.ALLOWED_ORIGINS.split(',').map(s => s.trim()).filter(s => {
    try { const url = new URL(s); return url.origin === s && ['https:', 'http:'].includes(url.protocol); } catch { return false; }
  });
}
function endpoint(env) {
  try {
    const url = new URL(env.QWEN_BASE_URL);
    // Configuration comes only from deployment, never from the client. Restrict secrets to the provider.
    if (url.protocol !== 'https:' || url.username || url.password || url.port || url.search || url.hash ||
      !/(^|\.)(maas\.aliyuncs\.com|dashscope\.aliyuncs\.com)$/u.test(url.hostname) ||
      !/^\/compatible-mode\/v1\/?$/u.test(url.pathname)) return null;
    return `${url.origin}${url.pathname.replace(/\/$/u, '')}/chat/completions`;
  } catch { return null; }
}
function configured(env) {
  return Boolean(typeof env.DASHSCOPE_API_KEY === 'string' && env.DASHSCOPE_API_KEY.trim() && endpoint(env) &&
    origins(env).length && typeof env.ANALYZE_RATE_LIMITER?.limit === 'function');
}
function response(body, status, origin, extra = {}) {
  return new Response(body === null ? null : JSON.stringify(body), { status, headers: {
    'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff', Vary: 'Origin',
    ...(origin ? { 'Access-Control-Allow-Origin': origin } : {}), ...extra,
  } });
}
async function boundedText(message, maximum, tooLarge) {
  const claimed = Number(message.headers.get('Content-Length'));
  if (Number.isFinite(claimed) && claimed > maximum) throw tooLarge;
  const reader = message.body?.getReader();
  if (!reader) return '';
  const decoder = new TextDecoder('utf-8', { fatal: true });
  let size = 0, content = '';
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > maximum) { await reader.cancel(); throw tooLarge; }
      content += decoder.decode(value, { stream: true });
    }
    return content + decoder.decode();
  } finally { reader.releaseLock(); }
}
function validateInput(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input) ||
    Object.keys(input).some(k => !['image', 'scene', 'consent'].includes(k)) ||
    input.consent !== true || !['daily', 'avatar', 'work'].includes(input.scene) || typeof input.image !== 'string' ||
    input.image.length > MAX_IMAGE_BYTES / 3 * 4 + 64) throw invalid();
  const match = /^data:image\/(jpeg|png|webp);base64,([A-Za-z0-9+/]+={0,2})$/u.exec(input.image);
  if (!match || match[2].length % 4 !== 0) throw invalid();
  let bytes;
  try { bytes = atob(match[2]); } catch { throw invalid(); }
  if (!bytes.length || bytes.length > MAX_IMAGE_BYTES || btoa(bytes) !== match[2]) throw invalid();
  const signature = [...bytes.slice(0, 12)].map(c => c.charCodeAt(0));
  const mime = match[1];
  const valid = mime === 'jpeg' ? signature[0] === 255 && signature[1] === 216 && signature[2] === 255 :
    mime === 'png' ? [137,80,78,71,13,10,26,10].every((v,i) => signature[i] === v) :
      bytes.startsWith('RIFF') && bytes.slice(8,12) === 'WEBP';
  if (!valid) throw invalid();
  return { image: input.image, scene: input.scene };
}
async function clientKey(request) {
  const ip = request.headers.get('CF-Connecting-IP');
  if (!ip || ip.length > 64 || !/^[a-fA-F0-9.:]+$/u.test(ip)) throw new SafeError(503, 'UNAVAILABLE', '分析服务暂不可用，请稍后重试。');
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(`firstlook:analyze:${ip}`));
  return `analyze:${Array.from(new Uint8Array(digest), b => b.toString(16).padStart(2, '0')).join('')}`;
}

export function createHandler({ fetchImpl = globalThis.fetch, timeoutMs = 45000 } = {}) {
  return async function handle(request, env = {}) {
    const origin = request.headers.get('Origin');
    const allowed = origin && origins(env).includes(origin) ? origin : null;
    const pathname = new URL(request.url).pathname;
    try {
      if (!['/api/analyze', '/api/health'].includes(pathname)) throw new SafeError(404, 'NOT_FOUND', '未找到此接口。');
      if (pathname === '/api/health' && request.method === 'GET') {
        if (origin && !allowed) throw new SafeError(403, 'ORIGIN_DENIED', '此来源未获授权。');
        return response({ configured: configured(env) }, 200, allowed);
      }
      if (!allowed) throw new SafeError(403, 'ORIGIN_DENIED', '此来源未获授权，请从已配置的网站发起分析。');
      if (request.method === 'OPTIONS') {
        const headers = (request.headers.get('Access-Control-Request-Headers') || '').toLowerCase().split(',').map(s => s.trim()).filter(Boolean);
        if (request.headers.get('Access-Control-Request-Method') !== 'POST' || headers.some(h => h !== 'content-type')) throw new SafeError(403, 'ORIGIN_DENIED', '此请求未获授权。');
        return response(null, 204, allowed, { 'Access-Control-Allow-Methods': 'POST, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type', 'Access-Control-Max-Age': '600' });
      }
      if (pathname !== '/api/analyze' || request.method !== 'POST') throw new SafeError(405, 'METHOD_NOT_ALLOWED', '此接口不支持该请求方式。');
      if (!configured(env)) throw new SafeError(503, 'NOT_CONFIGURED', '真实分析尚未开通，请先体验示例。');
      if (!/^application\/json(?:\s*;.*)?$/iu.test(request.headers.get('Content-Type') || '')) throw new SafeError(415, 'UNSUPPORTED_TYPE', '请使用正确的照片上传格式。');
      let input;
      const large = new SafeError(413, 'TOO_LARGE', '照片数据太大，请压缩后重试。');
      try { input = validateInput(JSON.parse(await boundedText(request, MAX_REQUEST_BYTES, large))); }
      catch (error) { if (error instanceof SafeError) throw error; throw invalid(); }
      let result;
      try { result = await env.ANALYZE_RATE_LIMITER.limit({ key: await clientKey(request) }); }
      catch { throw new SafeError(503, 'UNAVAILABLE', '分析服务暂不可用，请稍后重试。'); }
      if (result?.success !== true) throw new SafeError(429, 'RATE_LIMITED', '分析次数较多，请一分钟后再试。');
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), timeoutMs);
      const cancel = () => controller.abort();
      request.signal.addEventListener('abort', cancel, { once: true });
      if (request.signal.aborted) controller.abort();
      try {
        controller.signal.throwIfAborted();
        const upstream = await fetchImpl(endpoint(env), {
          method: 'POST', headers: { Authorization: `Bearer ${env.DASHSCOPE_API_KEY}`, 'Content-Type': 'application/json' },
          redirect: 'manual', signal: controller.signal,
          body: JSON.stringify({ model: env.QWEN_MODEL || 'qwen3-vl-plus', enable_thinking: false, stream: false,
            messages: [{ role: 'system', content: SYSTEM_PROMPT }, userMessage(input.scene, input.image)], response_format: REPORT_RESPONSE_FORMAT }),
        });
        controller.signal.throwIfAborted();
        if (!upstream.ok) {
          await upstream.body?.cancel();
          if (upstream.status === 429) throw new SafeError(503, 'UPSTREAM_BUSY', 'AI服务暂时繁忙，请稍后重试。');
          throw new SafeError(502, 'UPSTREAM_ERROR', 'AI服务暂时未能完成分析，请稍后重试。');
        }
        const raw = JSON.parse(await boundedText(upstream, MAX_RESPONSE_BYTES, new Error('oversize')));
        const choice = raw?.choices?.[0];
        if (choice?.finish_reason !== 'stop' || choice.message?.refusal || typeof choice.message?.content !== 'string') throw new Error('invalid completion');
        const report = validateReport(JSON.parse(choice.message.content).result);
        controller.signal.throwIfAborted();
        return response({ mode: 'live', report }, 200, allowed);
      } catch (error) {
        if (request.signal.aborted) throw new SafeError(499, 'CANCELLED', '分析已取消。');
        if (controller.signal.aborted) throw new SafeError(504, 'TIMEOUT', '分析超时，请稍后重试。');
        if (error instanceof SafeError) throw error;
        throw new SafeError(502, 'INVALID_ANALYSIS', '这次未能生成有效报告，请稍后重试或换一张清晰的单人照片。');
      } finally { clearTimeout(timer); request.signal.removeEventListener('abort', cancel); }
    } catch (error) {
      const safe = error instanceof SafeError ? error : new SafeError(503, 'UNAVAILABLE', '分析服务暂不可用，请稍后重试。');
      return response({ error: { code: safe.code, message: safe.message } }, safe.status, allowed, safe.status === 429 ? { 'Retry-After': '60' } : {});
    }
  };
}

export default { fetch: createHandler() };
